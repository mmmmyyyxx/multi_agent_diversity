"""Explicit policy API and opt-in adapters; never registered in current runtime."""
from collections import OrderedDict
from dataclasses import dataclass,asdict,replace
from time import monotonic
from .policy import Policy,digest
from .extraction import extract_final,normalize_surface
from .supervisor import Supervisor,WorkerFailure,WorkerTimeout

FINAL={'CORRECT','INCORRECT','INVALID_OUTPUT'}
UNKNOWN={'UNSUPPORTED','EVALUATOR_TIMEOUT','INFRASTRUCTURE_FAILURE','REFERENCE_INVALID'}
class UnresolvedMathScore(RuntimeError):pass

@dataclass(frozen=True)
class ScoreResult:
    policy_id:str
    policy_sha256:str
    prediction_extracted:str
    normalized_prediction:str
    normalized_reference:str
    prediction_valid:bool
    status:str
    correct:bool|None
    reason:str
    scoring_stage:str
    elapsed_ms:float
    reference_id:str
    input_sha256:str
    extraction_policy_id:str='MATH_GOLD_BLIND_DECLARATIONS_V1'
    unified_prediction_extracted:str=''
    unified_prediction_valid:bool=False
    cache_hit:bool=False
    symbolic_parse_calls:int=0
    symbolic_verify_calls:int=0
    symbolic_modules_loaded:bool|None=None
    network_attempt_count:int|None=None
    def __post_init__(self):
        if self.status not in FINAL|UNKNOWN:raise ValueError('UNKNOWN_SCORE_STATUS')
        if (self.status in UNKNOWN)!=(self.correct is None):raise ValueError('UNKNOWN_SCORE_CANNOT_BE_BOOLEAN')
        if self.status in FINAL and type(self.correct) is not bool:raise ValueError('DETERMINED_SCORE_REQUIRES_BOOLEAN')
    def __bool__(self):raise TypeError('Inspect status/correct explicitly; unknown is not incorrect')
    def binary(self):
        if self.correct is None:raise UnresolvedMathScore(self.status+':'+self.reason)
        return int(self.correct)
    def to_dict(self):return asdict(self)

@dataclass(frozen=True)
class EquivalenceResult:
    policy_id:str
    policy_sha256:str
    status:str
    equivalent:bool|None
    reason:str
    elapsed_ms:float
    pair_sha256:str
    def __bool__(self):raise TypeError('Vote comparison is tri-state; inspect equivalent explicitly')

class MathScorer:
    def __init__(self,policy:Policy):
        if not isinstance(policy,Policy):raise TypeError('AN_EXPLICIT_VERSIONED_POLICY_IS_REQUIRED')
        self.policy=policy;self.frozen_policy_sha256=policy.sha256;self.supervisor=Supervisor(policy);self.cache=OrderedDict();self.backend_requests=0
    def _call(self,operation,reference,prediction,finish_reason='stop',type_hints=None):
        with self.supervisor.lock:return self._call_locked(operation,reference,prediction,finish_reason,type_hints)
    def _call_locked(self,operation,reference,prediction,finish_reason='stop',type_hints=None):
        started=monotonic();p=self.policy
        if p.sha256!=self.frozen_policy_sha256:
            self.supervisor.close();raise RuntimeError('SCORING_SOURCE_CHANGED_FRESH_PROCESS_REQUIRED')
        short_ref=reference[:p.max_expression_characters] if isinstance(reference,str) else None
        reference_id=digest(dict(value=short_ref,length=len(reference) if isinstance(reference,str) else None))
        if not isinstance(prediction,str) or len(prediction)>p.max_raw_characters or not isinstance(reference,str) or len(reference)>p.max_expression_characters:
            status='REFERENCE_INVALID' if not isinstance(reference,str) or len(reference)>p.max_expression_characters else 'UNSUPPORTED'
            return ScoreResult(p.policy_id,p.sha256,'','',normalize_surface(short_ref or ''),False,status,None,'INPUT_SHAPE_OR_LENGTH_LIMIT','input_limit',
                (monotonic()-started)*1000,reference_id,digest(dict(operation=operation,reference_id=reference_id,bounded_input=True)))
        hints=type_hints or {}
        if any(k not in ('reference','prediction') or v not in ('scalar','relation','tuple','interval','set','matrix') for k,v in hints.items()):raise ValueError('INVALID_EXPLICIT_TYPE_HINT')
        payload=dict(operation=operation,reference=reference,prediction=prediction,finish_reason=finish_reason,type_hints=hints,policy=asdict(p),policy_sha256=p.sha256)
        key=digest(payload);payload['input_sha256']=key
        if key in self.cache:
            result=self.cache.pop(key);self.cache[key]=result
            return replace(result,cache_hit=True,elapsed_ms=(monotonic()-started)*1000,
                symbolic_parse_calls=0,symbolic_verify_calls=0)
        extraction=extract_final(prediction,finish_reason,p) if operation=='score' else None
        try:
            self.backend_requests+=1;value=self.supervisor.request(payload)
            if value.get('policy_sha256')!=p.sha256:raise WorkerFailure('WORKER_POLICY_ECHO_MISMATCH')
            status=value['status'];correct=value['correct'];reason=value['reason']
            if status not in FINAL|UNKNOWN:raise WorkerFailure('WORKER_INVALID_STATUS')
            if status=='INFRASTRUCTURE_FAILURE':self.supervisor._stop()
        except WorkerTimeout as exc:value={};status='EVALUATOR_TIMEOUT';correct=None;reason=str(exc)
        except WorkerFailure as exc:value={};status='INFRASTRUCTURE_FAILURE';correct=None;reason=str(exc)
        except (KeyError,ValueError,TypeError):value={};status='INFRASTRUCTURE_FAILURE';correct=None;reason='WORKER_RESULT_SCHEMA_FAILURE'
        result=ScoreResult(p.policy_id,p.sha256,
            value.get('prediction_extracted',extraction.payload if extraction else prediction),
            value.get('normalized_prediction',normalize_surface(extraction.payload if extraction else prediction)),
            value.get('normalized_reference',normalize_surface(reference)),
            value.get('prediction_valid',extraction.valid if extraction else True),status,correct,reason,
            value.get('scoring_stage','worker_supervision'),(monotonic()-started)*1000,reference_id,key,
            extraction_policy_id=value.get('extraction_policy_id',p.extraction_id),
            unified_prediction_extracted=extraction.payload if extraction else '',unified_prediction_valid=extraction.valid if extraction else False,
            symbolic_parse_calls=value.get('symbolic_parse_calls',0),symbolic_verify_calls=value.get('symbolic_verify_calls',0),
            symbolic_modules_loaded=value.get('symbolic_modules_loaded'),network_attempt_count=value.get('network_attempt_count'))
        self.cache[key]=result
        while len(self.cache)>p.cache_entries:self.cache.popitem(last=False)
        return result
    def score_math(self,reference,raw_prediction,*,finish_reason='stop',type_hints=None):
        return self._call('score',reference,raw_prediction,finish_reason,type_hints)
    def compare_answers(self,left_payload,right_payload,*,left_type=None,right_type=None):
        # Cache comparison identities symmetrically. Mathematical symmetry is
        # separately checked inside the semantic worker, not assumed from verify.
        if not isinstance(left_payload,str) or not isinstance(right_payload,str):raise TypeError('EXTRACTED_PAYLOADS_REQUIRED')
        (left,lt),(right,rt)=sorted([(left_payload,left_type or ''),(right_payload,right_type or '')])
        hints={k:v for k,v in [('reference',lt),('prediction',rt)] if v};value=self._call('equivalence',left,right,type_hints=hints)
        return EquivalenceResult(value.policy_id,value.policy_sha256,value.status,value.correct,value.reason,value.elapsed_ms,
            digest(dict(policy=value.policy_sha256,pair=[left,right],type_hints=hints)))
    def close(self):self.supervisor.close()
    def __enter__(self):return self
    def __exit__(self,*args):self.close()

def score_math(reference,raw_prediction,policy,*,finish_reason='stop',type_hints=None):
    """Convenience single-call facade; use MathScorer as a context for batches."""
    with MathScorer(policy) as scorer:return scorer.score_math(reference,raw_prediction,finish_reason=finish_reason,type_hints=type_hints)

class OfflineMathAdapter:
    """Future explicit integration seam; unresolved states cannot become score0."""
    def __init__(self,policy):self.scorer=MathScorer(policy)
    def score_saved(self,reference,prediction):
        return self.scorer.score_math(reference,prediction.text,finish_reason=prediction.finish_reason)
    def member_score(self,reference,prediction):return self.score_saved(reference,prediction).binary()
    def vote_relation(self,left,right):return self.scorer.compare_answers(left,right)
    def close(self):self.scorer.close()
