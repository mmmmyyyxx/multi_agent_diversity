"""Offline NDJSON worker; hard wall supervision belongs to its parent process."""
import json,os,socket,sys
from dataclasses import asdict
from .policy import Policy,PINS,digest
from .extraction import extract_final,normalize_surface,balanced

NETWORK_ATTEMPTS=0
def blocked(*args,**kwargs):
    global NETWORK_ATTEMPTS
    NETWORK_ATTEMPTS+=1
    raise RuntimeError('MATH_SCORING_NETWORK_FORBIDDEN')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=blocked

def result(status,correct,reason,stage,extracted,reference,prediction_valid,**extra):
    return dict(status=status,correct=correct,reason=reason,scoring_stage=stage,
        prediction_extracted=extracted,normalized_prediction=normalize_surface(extracted),
        normalized_reference=normalize_surface(reference),prediction_valid=prediction_valid,**extra)

def evaluate(request):
    p=Policy(**request['policy']);gold=request['reference'];raw=request['prediction'];operation=request['operation']
    if request['policy_sha256']!=p.sha256:raise ValueError('WORKER_POLICY_HASH_MISMATCH')
    extraction=extract_final(raw,request.get('finish_reason','stop'),p) if operation=='score' else None
    if not isinstance(gold,str) or not gold.strip() or len(gold)>p.max_expression_characters or not balanced(gold,p.max_nesting):
        return result('REFERENCE_INVALID',None,'REFERENCE_SHAPE_INVALID','reference',raw if operation=='equivalence' else extraction.payload,gold if isinstance(gold,str) else '',True if extraction is None else extraction.valid)
    if operation=='equivalence':payload=raw;valid=True
    else:payload=extraction.payload;valid=extraction.valid
    if p.policy_id=='maspo_compat_v1':
        if operation=='equivalence':return result('UNSUPPORTED',None,'MASPO_REFERENCE_NOT_APPROVED_FOR_VOTING','compatibility',raw,gold,True)
        from .compat_maspo import extract_answer,normalize_answer
        answer=extract_answer(raw);left=normalize_answer(gold);right=normalize_answer(answer);correct=left==right
        return dict(status='CORRECT' if correct else 'INCORRECT',correct=correct,reason='MASPO_ORIGINAL_STRING_RULES_REFERENCE_ONLY',
            scoring_stage='maspo_original_compatibility',prediction_extracted=answer,normalized_prediction=right,normalized_reference=left,
            prediction_valid=bool(answer),unified_prediction_extracted=extraction.payload,unified_prediction_valid=extraction.valid,
            extraction_policy_id='MASPO_ORIGINAL_EXTRACTOR_REFERENCE_ONLY')
    if not valid:
        limited=extraction.reason in ('RAW_LENGTH_LIMIT','EXPRESSION_LENGTH_LIMIT','NESTING_LIMIT','DECLARATION_LIMIT')
        return result('UNSUPPORTED' if limited else 'INVALID_OUTPUT',None if limited else False,extraction.reason,'extraction',payload,gold,False)
    if p.policy_id=='paper_extracted_exact_v1':
        correct=normalize_surface(gold)==normalize_surface(payload)
        return result('CORRECT' if correct else 'INCORRECT',correct,'NORMALIZED_STRING_EQUALITY_NOT_MATH_EQUIVALENCE','surface_exact',payload,gold,True)
    import importlib.metadata
    for package,version in PINS.items():
        if importlib.metadata.version(package)!=version:raise RuntimeError('PINNED_DEPENDENCY_MISMATCH')
    from .semantic import compare,COUNTS
    before=dict(COUNTS)
    status,correct,reason=compare(gold,payload,p,symmetric=operation=='equivalence',type_hints=request.get('type_hints'))
    counts={k:COUNTS[k]-before[k] for k in COUNTS}
    value=result(status,correct,reason,'semantic_native' if any(counts.values()) else 'semantic_direct_or_cached_parse',payload,gold,True,
        symbolic_parse_calls=counts['parse'],symbolic_verify_calls=counts['verify'])
    from .kernel_binding import normalize_native_input
    value['normalized_prediction']=normalize_native_input(normalize_surface(payload))
    value['normalized_reference']=normalize_native_input(normalize_surface(gold))
    return value

def main():
    if os.name!='nt':
        import resource
        memory=int(sys.argv[1])*1024*1024;resource.setrlimit(resource.RLIMIT_AS,(memory,memory))
    print(json.dumps(dict(ready=True,pid=os.getpid())),flush=True)
    for line in sys.stdin.buffer:
        try:
            if len(line)>1_048_576:raise ValueError('WORKER_REQUEST_LIMIT')
            request=json.loads(line)
            # This is an offline protocol seam, not a caller-supplied executable.
            if request.get('operation') not in ('score','equivalence'):raise ValueError('UNKNOWN_WORKER_OPERATION')
            value=evaluate(request);value['input_sha256']=request['input_sha256'];value['policy_sha256']=request['policy_sha256']
            value['symbolic_modules_loaded']='sympy' in sys.modules or 'math_verify' in sys.modules
            value['network_attempt_count']=NETWORK_ATTEMPTS
            print(json.dumps(value,ensure_ascii=True,allow_nan=False),flush=True)
        except Exception as exc:
            print(json.dumps(dict(input_sha256=request.get('input_sha256') if 'request' in locals() else None,
                policy_sha256=request.get('policy_sha256') if 'request' in locals() else None,
                status='INFRASTRUCTURE_FAILURE',correct=None,reason=type(exc).__name__,network_attempt_count=NETWORK_ATTEMPTS)),flush=True)
    return 0
if __name__=='__main__':raise SystemExit(main())
