"""Reuse the unchanged pinned local kernel; never import the sibling repository."""
def load():
    from ..benchmarks import math_domain_worker as kernel
    kernel.initialize()
    return kernel

def normalize_native_input(value):
    from ..benchmarks.math_flexible_answer import normalize_payload
    return normalize_payload(value)

def dependency_sources():
    from pathlib import Path
    base=Path(__file__).parents[1]/'benchmarks'
    return {'kernel':base/'math_domain_worker.py','settings':base/'math_domain_v2.py','normalization':base/'math_flexible_answer.py'}
