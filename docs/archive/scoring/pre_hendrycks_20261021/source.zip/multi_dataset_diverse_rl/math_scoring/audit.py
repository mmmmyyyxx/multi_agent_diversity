"""Single-use, zero-network replay of saved responses; never a formal runner."""
from pathlib import Path
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
import argparse,json,os,socket,time,threading,statistics,math,hashlib
from .api import MathScorer
from .policy import policy_for,POLICIES,digest

def blocked(*a,**k):raise RuntimeError('MATH_AUDIT_NETWORK_FORBIDDEN')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def root():return next(p for p in Path(__file__).resolve().parents if (p/'AGENTS.md').exists())

def replay(input_path,output,*,workers=4,policies=POLICIES):
    socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=blocked
    if not 1<=workers<=8:raise ValueError('AUDIT_WORKER_LIMIT')
    if not output.resolve().is_relative_to((root()/'runs').resolve()):raise ValueError('PRIVATE_AUDIT_DIRECTORY_REQUIRED')
    if output.exists():raise FileExistsError('PRESERVE_PRIOR_AUDIT_USE_A_FRESH_OUTPUT_DIRECTORY')
    output.mkdir(parents=True);started=time.monotonic();initial=sha(input_path)
    cases=[json.loads(line) for line in input_path.read_bytes().splitlines()];ids=[c['audit_id'] for c in cases];assert len(ids)==len(set(ids))
    policy_objects={p:policy_for(p) for p in policies}
    sources={p.name:sha(p) for p in Path(__file__).parent.glob('*.py')}
    identity=dict(input_sha256=initial,policy_hashes={p:v.sha256 for p,v in policy_objects.items()},source_files=sources,workers=workers,
        operation='OFFLINE_SAVED_RESPONSE_COUNTERFACTUAL_NO_FORMAL_RESULTS_WRITTEN')
    write(output/'scope.json',dict(identity=digest(identity),**identity,real_model_calls=0))
    local=threading.local();scorers=[];lock=threading.Lock();done=0
    def one(case):
        nonlocal done
        if not hasattr(local,'scorers'):
            local.scorers={p:MathScorer(v) for p,v in policy_objects.items()}
            with lock:scorers.extend(local.scorers.values())
        results={p:s.score_math(case['gold'],case['raw'],finish_reason=case.get('finish_reason','stop')).to_dict() for p,s in local.scorers.items()}
        with lock:
            done+=1
            if done%250==0 or done==len(cases):print(json.dumps(dict(completed=done,total=len(cases))),flush=True)
        return dict(audit_id=case['audit_id'],cell=case.get('cell'),reference_id=digest(case.get('example_id','')),
            original_raw=case['raw'],reference_private=case['gold'],finish_reason=case.get('finish_reason','stop'),policies=results)
    try:
        with ThreadPoolExecutor(max_workers=workers) as pool:records=list(pool.map(one,cases))
    finally:
        for s in scorers:s.close()
    assert initial==sha(input_path)
    assert sources=={p.name:sha(p) for p in Path(__file__).parent.glob('*.py')},'SCORER_SOURCE_CHANGED_DURING_AUDIT'
    with (output/'results.private.jsonl').open('w',encoding='utf-8',newline='\n') as f:
        for r in records:f.write(json.dumps(r,sort_keys=True,ensure_ascii=True)+'\n')
    sanitized=[]
    for r in records:
        sanitized.append(dict(case_id=digest(r['audit_id']),cell=r['cell'],reference_id=r['reference_id'],policies={p:{k:v[k] for k in [
            'policy_id','policy_sha256','status','correct','reason','scoring_stage','elapsed_ms','prediction_valid','cache_hit','symbolic_parse_calls','symbolic_verify_calls','symbolic_modules_loaded','network_attempt_count']} for p,v in r['policies'].items()}))
    with (output/'sanitized_case_index.jsonl').open('w',encoding='utf-8',newline='\n') as f:
        for r in sanitized:f.write(json.dumps(r,sort_keys=True,ensure_ascii=True)+'\n')
    stats={}
    for p in policies:
        values=[r['policies'][p] for r in records];times=sorted(v['elapsed_ms'] for v in values);n=len(values)
        quant=lambda q:times[max(0,math.ceil(q*n)-1)]
        counts=Counter(v['status'] for v in values);unknown=sum(v['correct'] is None for v in values);correct=sum(v['correct'] is True for v in values)
        stats[p]=dict(count=n,statuses=dict(counts),known_correct=correct,unresolved=unknown,
            fixed_denominator_accuracy_bounds=[correct/n,(correct+unknown)/n],
            mean_ms=statistics.mean(times),p95_ms=quant(.95),p99_ms=quant(.99),maximum_ms=max(times),
            symbolic_parse_calls=sum(v['symbolic_parse_calls'] for v in values),symbolic_verify_calls=sum(v['symbolic_verify_calls'] for v in values),
            known_network_attempts=sum(v['network_attempt_count'] or 0 for v in values),uncompleted_worker_network_witnesses=sum(v['network_attempt_count'] is None for v in values))
    lifecycle=dict(supervisors=len(scorers),launchers_spawned=sum(len(s.supervisor.spawned) for s in scorers),
        actual_workers_started=sum(len(s.supervisor.worker_pids) for s in scorers),launchers_reaped=sum(len(s.supervisor.terminated) for s in scorers),
        all_workers_closed=all(s.supervisor.process is None and s.supervisor.reader is None for s in scorers))
    write(output/'summary.json',dict(status='OFFLINE_REPLAY_COMPLETE',identity=digest(identity),cases=len(cases),policies=stats,
        source_and_input_hashes_preserved=True,new_model_calls=0,new_model_tokens=0,historical_results_written=False,
        wall_seconds=time.monotonic()-started,lifecycle=lifecycle))
    print('PASS offline replay complete; formal experiment records untouched',flush=True)
    return records

def main(argv=None):
    parser=argparse.ArgumentParser(description='Offline saved-response scoring; no model or experiment execution')
    parser.add_argument('--input',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--workers',type=int,default=4);parser.add_argument('--policies',nargs='+',choices=POLICIES,default=list(POLICIES))
    a=parser.parse_args(argv);replay(a.input,a.output,workers=a.workers,policies=a.policies)
if __name__=='__main__':main()
