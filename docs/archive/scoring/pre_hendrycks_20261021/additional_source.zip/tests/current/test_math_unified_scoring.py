"""Opt-in scoring contract; fake supervision faults never invoke a model."""
from dataclasses import replace
from pathlib import Path
import sys,time,json
import pytest
from multi_dataset_diverse_rl.math_scoring import MathScorer,policy_for,UnresolvedMathScore
from multi_dataset_diverse_rl.math_scoring.policy import POLICIES
from multi_dataset_diverse_rl.math_scoring.extraction import extract_final,normalize_surface
from multi_dataset_diverse_rl.math_scoring.supervisor import Supervisor

@pytest.fixture(scope='module')
def scorers():
    values={p:MathScorer(policy_for(p)) for p in POLICIES}
    yield values
    for s in values.values():s.close()

CASES=[
 ('1/2',r'\frac{1}{2}',[False,True,True]),
 ('1/2','0.5',[False,False,True]),
 ('0.25','0.5/2',[False,False,True]),
 (r'\frac{1}{2}',r'\dfrac{1}{2}',[True,True,True]),
 ('x^2-1','(x-1)(x+1)',[False,False,True]),
 ('2',r'\sqrt{4}',[False,False,True]),
 ('(0,1)','[0,1]',[False,True,None]),
 ('[0,1]','[0,1)',[False,True,False]), # Original MASPO erases both bracket distinctions.
 ('{1,2}','(1,2)',[False,False,None]),
 ('(1,2)','(2,1)',[False,False,None]),
 ('{1,2}','{2,1}',[False,False,True]),
 ('{1,2}','{1,1,2}',[False,False,True]),
 ('x=1','1',[False,False,False]),
 ('x','X',[False,True,False]),
 ('1','1.00000001',[False,False,False]),
 (r'\pi',r'\pi',[True,True,True]),
 (r'\begin{pmatrix}1&2\\3&4\end{pmatrix}',r'\begin{pmatrix}1&3\\2&4\end{pmatrix}',[False,False,False]),
]
@pytest.mark.parametrize('gold,answer,expected',CASES)
@pytest.mark.parametrize('policy_id',POLICIES)
def test_policy_distinctions_and_type_safety(scorers,gold,answer,expected,policy_id):
    r=scorers[policy_id].score_math(gold,'Final answer: '+answer)
    # MASPO's fallback retains the label when there is no original answer tag/box.
    if policy_id=='maspo_compat_v1':r=scorers[policy_id].score_math(gold,'<answer>'+answer+'</answer>')
    assert r.correct is expected[POLICIES.index(policy_id)],r
    assert r.policy_sha256==policy_for(policy_id).sha256
    assert r.network_attempt_count==0
    if policy_id=='paper_extracted_exact_v1':assert r.symbolic_modules_loaded is False

@pytest.mark.parametrize('raw,valid',[
 ('<answer>2</answer>',True),
 (r'Work. The result is \boxed{\frac{1}{2}}.',True),
 (r'Final answer: \boxed{\boxed{2}}',True),
 ('Final answer:\n\\[2\\]',True),
 ('Thus the value is:\n\\[\n\\boxed{2}\n\\]',True),
 ('Thus the value is:\n\\[\n2\n\\]',True),
 (r'Thus the value is \(\boxed{2}\).',True),
 ('Thus 1.\nContinue with more work.\nUnmarked conclusion remains uncertain.',False),
 ('Final answer:\nFinal answer: 2',True),
 ('Working: \\boxed{1} then more work.\nFinally \\(\\boxed{2}\\).',True),
 (r'Final answer: \boxed{2} because the calculation gives it.',True),
 ('Final answer: 1\nFinal answer: 2',False),
 ('<answer>1</answer><answer>2</answer>',False),
 ('<answer>2',False),
 (r'Final answer: \boxed{2',False),
 ('2',False),
 ('Working: 2.\nFinal answer: 3',True),
 ('Therefore, we simplify the expression.\nThus x=3.\nFinal answer: 2',True),
 ('Therefore 1.\nThus 2.',True),
 ('Final answer: 1 or 2',False),
])
def test_gold_blind_extraction(raw,valid):
    p=policy_for('paper_extracted_exact_v1');a=extract_final(raw,'stop',p);assert a.valid is valid,a
    if not valid:assert a.reason!='EXPLICIT_FINAL_DECLARATION'

@pytest.mark.parametrize('policy_id',['paper_extracted_exact_v1','math_semantic_v1'])
def test_truncation_conflicts_and_reference_independence(scorers,policy_id):
    s=scorers[policy_id]
    for ref in ['1','2']:
        r=s.score_math(ref,'Final answer: 1\nFinal answer: 2');assert r.status=='INVALID_OUTPUT' and r.correct is False
    r=s.score_math('2','Final answer: 2',finish_reason='length');assert r.status=='INVALID_OUTPUT'
    bad=s.score_math('','Final answer: 2');assert bad.status=='REFERENCE_INVALID' and bad.correct is None and bad.prediction_valid
    with pytest.raises(UnresolvedMathScore):bad.binary()
    with pytest.raises(TypeError):bool(bad)

def test_safe_normalization_preserves_mathematical_objects():
    for a,b in [('[0,1]','(0,1)'),('{1,2}','(1,2)'),('1 2','12'),('x','X'),('-1','1'),('(1,2)','(2,1)')]:assert normalize_surface(a)!=normalize_surface(b)
    assert normalize_surface(r'\left[0,1\right]')=='[0,1]'
    assert normalize_surface(r'\dfrac {1}{2}')==r'\frac{1}{2}'

@pytest.mark.parametrize('gold,raw',[
 ('2', 'Thus the value is:\n\\[\n\\boxed{2}\n\\]'),
 ('2', 'Thus the value is:\n\\[\n2\n\\]'),
 ('2', 'Final answer:\nFinal answer: 2'),
 (r'\sqrt{5}', 'Final answer: \u221a5'),
 (r'\sqrt{9}', 'Final answer: \u221a(9)'),
 (r'2\pi', 'Final answer: 2\u03c0'),
 ('-2', 'Final answer: \u22122'),
])
def test_shared_boundaries_and_existing_native_presentation_adapter(scorers,gold,raw):
    r=scorers['math_semantic_v1'].score_math(gold,raw)
    assert r.correct is True,r
    assert r.prediction_extracted==extract_final(raw,'stop',policy_for('paper_extracted_exact_v1')).payload

def test_no_fallback_to_intermediate_conclusion():
    raw='Thus 1.\nWork continues with another result.\n\\boxed{2} followed by unlabelled explanation.'
    r=extract_final(raw,'stop',policy_for('paper_extracted_exact_v1'))
    assert not r.valid and r.payload==''

def test_bounded_large_powers_are_unknown_and_cached(scorers):
    s=scorers['math_semantic_v1'];r=s.score_math('1',r'Final answer: 2^{999999999}')
    assert r.status=='UNSUPPORTED' and r.correct is None
    before=s.backend_requests;again=s.score_math('1',r'Final answer: 2^{999999999}')
    assert again.status==r.status and again.cache_hit and s.backend_requests==before
    assert s.score_math('1',r'Final answer: 2^{\frac{999999999}{7}}').correct is None
    good=s.score_math('1024','Final answer: 2^{10}');assert good.correct is True

def test_semantic_finite_rational_values_need_no_kernel():
    with MathScorer(policy_for('math_semantic_v1')) as s:
        r=s.score_math('1/2','Final answer: 0.5');assert r.correct and r.symbolic_modules_loaded is False

def test_cached_result_does_not_recharge_symbolic_work():
    with MathScorer(policy_for('math_semantic_v1')) as s:
        first=s.score_math('2',r'Final answer: \sqrt{4}')
        assert first.correct is True and first.symbolic_parse_calls>0 and first.symbolic_verify_calls>0
        again=s.score_math('2',r'Final answer: \sqrt{4}')
        assert again.correct is True and again.cache_hit
        assert again.symbolic_parse_calls==again.symbolic_verify_calls==0

def test_policy_cache_identity_and_symmetric_vote(scorers):
    assert len({policy_for(p).sha256 for p in POLICIES})==3
    assert policy_for('math_semantic_v1',wall_seconds=2).sha256!=policy_for('math_semantic_v1').sha256
    s=scorers['math_semantic_v1'];a=s.compare_answers('1/2','0.5');b=s.compare_answers('0.5','1/2')
    assert a.equivalent is b.equivalent is True and a.pair_sha256==b.pair_sha256
    assert s.compare_answers('{1,2}','(1,2)',right_type='tuple').equivalent is False
    assert scorers['maspo_compat_v1'].compare_answers('1','1').equivalent is None
    with pytest.raises(TypeError):bool(a)

def test_explicit_tuple_interval_types_are_not_inferred_from_gold(scorers):
    s=scorers['math_semantic_v1']
    assert s.score_math('(1,2)','Final answer: (1,2)').status=='UNSUPPORTED'
    assert s.score_math('(1,2)','Final answer: (2,1)',type_hints={'reference':'tuple','prediction':'tuple'}).correct is False
    assert s.score_math('(0,1)','Final answer: [0,1]',type_hints={'reference':'interval'}).correct is False
    assert s.score_math('(1,2)','Final answer: (1,2)',type_hints={'reference':'tuple','prediction':'tuple'}).correct is True
    assert s.score_math('[0,1]','Final answer: [0,1]',type_hints={'reference':'tuple'}).correct is None

@pytest.mark.parametrize('limit,value',[('wall_seconds',0),('wall_seconds',100),('startup_seconds',100),('max_raw_characters',1000000),('memory_megabytes',0)])
def test_policy_rejects_unbounded_resources(limit,value):
    with pytest.raises(ValueError):policy_for('math_semantic_v1',**{limit:value})

FAULT_WORKER='''import sys,json,os,time
print(json.dumps({'ready':True,'pid':os.getpid()}),flush=True)
for line in sys.stdin:
 j=json.loads(line)
 if 'SLEEP' in j['prediction']:time.sleep(30)
 if 'CRASH' in j['prediction']:os._exit(23)
 if 'ALLOCATE' in j['prediction']:
  try:a=bytearray(400*1024*1024)
  except MemoryError:
   print(json.dumps({'input_sha256':j['input_sha256'],'policy_sha256':j['policy_sha256'],'status':'INFRASTRUCTURE_FAILURE','correct':None,'reason':'MEMORY_GUARD'}),flush=True);continue
 print(json.dumps({'input_sha256':j['input_sha256'],'policy_sha256':j['policy_sha256'],'status':'CORRECT','correct':True,'reason':'synthetic_response'}),flush=True)
'''
@pytest.mark.parametrize('fault,expected',[('SLEEP','EVALUATOR_TIMEOUT'),('CRASH','INFRASTRUCTURE_FAILURE'),('ALLOCATE','INFRASTRUCTURE_FAILURE')])
def test_real_process_deadline_memory_reaping_and_next_input(tmp_path,monkeypatch,fault,expected):
    path=tmp_path/'fault_worker.py';path.write_text(FAULT_WORKER,encoding='utf-8')
    monkeypatch.setattr(Supervisor,'_command',lambda self:[sys.executable,'-u',str(path)])
    p=policy_for('paper_extracted_exact_v1',wall_seconds=.12,memory_megabytes=96)
    with MathScorer(p) as s:
        started=time.monotonic();r=s.score_math('1','Final answer: '+fault)
        assert r.status==expected and r.correct is None,r
        assert time.monotonic()-started<4
        assert s.supervisor.process is None and s.supervisor.reader is None
        assert s.supervisor.spawned==s.supervisor.terminated
        with pytest.raises(UnresolvedMathScore):r.binary()
        # One failed input does not wedge the pool or trigger any model request.
        ok=s.score_math('1','Final answer: 1');assert ok.correct is True
    assert s.supervisor.spawned==s.supervisor.terminated

def test_input_limit_remains_unknown(scorers):
    r=scorers['paper_extracted_exact_v1'].score_math('1','Final answer: '+'1'*3000)
    assert r.status=='UNSUPPORTED' and r.correct is None

def test_invalid_reference_not_scored_as_model_error(scorers):
    for ref in ['1/0',r'\frac{1}{0}']:
        r=scorers['math_semantic_v1'].score_math(ref,'Final answer: 2')
        assert r.status=='REFERENCE_INVALID' and r.correct is None

def test_completed_semantics_stable_across_fresh_workers():
    results=[]
    for _ in range(3):
        with MathScorer(policy_for('math_semantic_v1')) as s:
            r=s.score_math('1/2','Final answer: 0.5');results.append((r.status,r.correct,r.prediction_extracted,r.policy_sha256))
    assert len(set(results))==1

def test_gold_first_and_vote_asymmetry_checked(monkeypatch):
    from multi_dataset_diverse_rl.math_scoring import semantic
    from sympy import Symbol
    calls=[]
    class Kernel:
        def parse_payload(self,value):return [Symbol(value)],True
        def verify_payload(self,left,right):
            calls.append((str(left[0]),str(right[0])));return str(left[0])=='goldvar'
    monkeypatch.setattr(semantic,'_KERNEL',Kernel());semantic.parse_scalar.cache_clear()
    p=policy_for('math_semantic_v1')
    status,correct,_=semantic.compare('goldvar','predvar',p);assert status=='CORRECT' and correct is True
    assert calls[0]==('goldvar','predvar')
    status,correct,reason=semantic.compare('goldvar','predvar',p,symmetric=True)
    assert status=='UNSUPPORTED' and correct is None and reason=='ASYMMETRIC_PINNED_COMPARISON'
    semantic.parse_scalar.cache_clear()

def test_source_identity_change_cannot_reuse_cached_score(monkeypatch):
    from multi_dataset_diverse_rl.math_scoring import policy as module
    with MathScorer(policy_for('paper_extracted_exact_v1')) as s:
        assert s.score_math('2','Final answer: 2').correct is True
        old=module.component_hashes()
        monkeypatch.setattr(module,'component_hashes',lambda:{**old,'extraction.py':'0'*64})
        with pytest.raises(RuntimeError,match='SCORING_SOURCE_CHANGED'):s.score_math('2','Final answer: 2')
        assert s.supervisor.closed and s.supervisor.spawned==s.supervisor.terminated
